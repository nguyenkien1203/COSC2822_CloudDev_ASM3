import json
import boto3
import uuid
from datetime import datetime
from decimal import Decimal
from boto3.dynamodb.conditions import Key, Attr

# Initialize DynamoDB
dynamodb = boto3.resource('dynamodb')
TABLE_NAME = 'restaurant-menu'
table = dynamodb.Table(TABLE_NAME)


def handler(event, context):
    """Main Lambda handler - routes requests to appropriate function"""
    http_method = event['requestContext']['http']['method']
    path = event['rawPath']
    
    print(f"Received: {http_method} {path}")
    
    try:
        # Route based on path and method
        if path == '/api/menu/available' and http_method == 'GET':
            return get_available_menus(event)
        elif path == '/api/menu' and http_method == 'GET':
            return get_all_menus(event)
        elif path == '/api/menu' and http_method == 'POST':
            return create_menu(event)
        elif path.startswith('/api/menu/') and path.endswith('/toggle-availability') and http_method == 'PATCH':
            menu_id = path.split('/')[3]
            return toggle_availability(menu_id, event)
        elif path.startswith('/api/menu/') and http_method == 'GET':
            menu_id = path.split('/')[3]
            return get_menu_by_id(menu_id)
        elif path.startswith('/api/menu/') and http_method == 'PUT':
            menu_id = path.split('/')[3]
            return update_menu(menu_id, event)
        elif path.startswith('/api/menu/') and http_method == 'DELETE':
            menu_id = path.split('/')[3]
            return delete_menu(menu_id)
        else:
            return response(404, {'error': 'Not Found'})
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return response(500, {'error': str(e)})


def get_available_menus(event):
    """GET /api/menu/available - Public endpoint"""
    params = event.get('queryStringParameters') or {}
    category = params.get('category')
    
    if category:
        # Use GSI to filter by category and availability
        result = table.query(
            IndexName='category-availability-index',
            KeyConditionExpression=Key('category').eq(category) & Key('isAvailable').eq('true')
        )
    else:
        # Scan for all available items
        result = table.scan(
            FilterExpression=Attr('isAvailable').eq('true')
        )
    
    items = result.get('Items', [])
    return response(200, convert_decimals(items))


def get_menu_by_id(menu_id):
    """GET /api/menu/{id} - Public endpoint"""
    result = table.get_item(Key={'id': menu_id})
    
    if 'Item' not in result:
        return response(404, {'error': 'Menu item not found'})
    
    return response(200, convert_decimals(result['Item']))


def get_all_menus(event):
    """GET /api/menu - Admin only"""
    # Check admin authorization
    auth_error = check_admin_auth(event)
    if auth_error:
        return auth_error
    
    result = table.scan()
    items = result.get('Items', [])
    return response(200, convert_decimals(items))


def create_menu(event):
    """POST /api/menu - Admin only"""
    auth_error = check_admin_auth(event)
    if auth_error:
        return auth_error
    
    body = json.loads(event.get('body', '{}'))
    now = datetime.utcnow().isoformat()
    
    item = {
        'id': str(uuid.uuid4()),
        'name': body.get('name'),
        'description': body.get('description', ''),
        'price': Decimal(str(body.get('price', 0))),
        'category': body.get('category', ''),
        'imageUrl': body.get('imageUrl', ''),
        'isAvailable': 'true',
        'preparationTime': body.get('preparationTime', 0),
        'calories': body.get('calories', 0),
        'createdAt': now,
        'updatedAt': now
    }
    
    table.put_item(Item=item)
    return response(201, convert_decimals(item))


def update_menu(menu_id, event):
    """PUT /api/menu/{id} - Admin only"""
    auth_error = check_admin_auth(event)
    if auth_error:
        return auth_error
    
    # Check if exists
    existing = table.get_item(Key={'id': menu_id})
    if 'Item' not in existing:
        return response(404, {'error': 'Menu item not found'})
    
    body = json.loads(event.get('body', '{}'))
    now = datetime.utcnow().isoformat()
    
    update_expr = "SET updatedAt = :updatedAt"
    expr_values = {':updatedAt': now}
    
    if 'name' in body:
        update_expr += ", #n = :name"
        expr_values[':name'] = body['name']
    if 'description' in body:
        update_expr += ", description = :desc"
        expr_values[':desc'] = body['description']
    if 'price' in body:
        update_expr += ", price = :price"
        expr_values[':price'] = Decimal(str(body['price']))
    if 'category' in body:
        update_expr += ", category = :cat"
        expr_values[':cat'] = body['category']
    if 'imageUrl' in body:
        update_expr += ", imageUrl = :img"
        expr_values[':img'] = body['imageUrl']
    if 'preparationTime' in body:
        update_expr += ", preparationTime = :prep"
        expr_values[':prep'] = body['preparationTime']
    if 'calories' in body:
        update_expr += ", calories = :cal"
        expr_values[':cal'] = body['calories']
    
    result = table.update_item(
        Key={'id': menu_id},
        UpdateExpression=update_expr,
        ExpressionAttributeValues=expr_values,
        ExpressionAttributeNames={'#n': 'name'} if 'name' in body else {},
        ReturnValues='ALL_NEW'
    )
    
    return response(200, convert_decimals(result['Attributes']))


def delete_menu(menu_id):
    """DELETE /api/menu/{id} - Admin only (no event needed for auth check in this impl)"""
    table.delete_item(Key={'id': menu_id})
    return response(204, None)


def toggle_availability(menu_id, event):
    """PATCH /api/menu/{id}/toggle-availability - Admin only"""
    auth_error = check_admin_auth(event)
    if auth_error:
        return auth_error
    
    # Get current item
    existing = table.get_item(Key={'id': menu_id})
    if 'Item' not in existing:
        return response(404, {'error': 'Menu item not found'})
    
    current = existing['Item']['isAvailable']
    new_value = 'false' if current == 'true' else 'true'
    
    result = table.update_item(
        Key={'id': menu_id},
        UpdateExpression="SET isAvailable = :val, updatedAt = :now",
        ExpressionAttributeValues={
            ':val': new_value,
            ':now': datetime.utcnow().isoformat()
        },
        ReturnValues='ALL_NEW'
    )
    
    return response(200, convert_decimals(result['Attributes']))


def check_admin_auth(event):
    """Check if user has ADMIN role from Cognito JWT claims"""
    try:
        claims = event.get('requestContext', {}).get('authorizer', {}).get('jwt', {}).get('claims', {})
        groups = claims.get('cognito:groups', '')
        
        # Groups can be string or list depending on how API Gateway passes it
        if isinstance(groups, str):
            groups = groups.split(',') if groups else []
        
        if 'ADMIN' not in groups:
            return response(403, {'error': 'Forbidden', 'message': 'Admin access required'})
        
        return None  # No error, user is authorized
    except Exception as e:
        print(f"Auth check error: {e}")
        return response(403, {'error': 'Forbidden'})


def response(status_code, body):
    """Create API Gateway response"""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS'
        },
        'body': json.dumps(body) if body else ''
    }


def convert_decimals(obj):
    """Convert Decimal types to float for JSON serialization"""
    if isinstance(obj, list):
        return [convert_decimals(i) for i in obj]
    elif isinstance(obj, dict):
        return {k: convert_decimals(v) for k, v in obj.items()}
    elif isinstance(obj, Decimal):
        return float(obj)
    else:
        return obj
